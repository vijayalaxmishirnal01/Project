export class Employee {
    dtoeid!:any;
    dtoename!:any;
    dtoemail!:any;
    dtosalary!:any;
    dtodes!:any;
    dpm!:any;
}
