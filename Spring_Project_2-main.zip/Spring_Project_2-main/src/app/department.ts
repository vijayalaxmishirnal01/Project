export class Department {
   dtodid!:any;
   dtodname!:any;
   emp!:any;

}
