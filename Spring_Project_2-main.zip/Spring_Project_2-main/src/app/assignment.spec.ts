import { Assignment } from './assignment';

describe('Assignment', () => {
  it('should create an instance', () => {
    expect(new Assignment()).toBeTruthy();
  });
});
