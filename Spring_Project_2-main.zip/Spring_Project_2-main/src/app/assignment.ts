export class Assignment {
empId!:number;
deptId!:number;
}
